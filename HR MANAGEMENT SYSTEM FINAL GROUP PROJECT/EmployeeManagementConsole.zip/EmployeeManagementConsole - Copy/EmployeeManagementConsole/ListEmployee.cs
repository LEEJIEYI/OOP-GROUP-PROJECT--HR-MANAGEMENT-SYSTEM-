﻿using EmployeeManagementConsole;
using System;
using System.Collections.Generic;
using System.Linq;

class ListEmployee
{
    static List<Employee> employees = new List<Employee>();
    static int nextId = 1;

    static void Main()
    {
        while (true)
        {
            Console.WriteLine("Employee Management System");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. Edit Employee");
            Console.WriteLine("3. Delete Employee");
            Console.WriteLine("4. Assign Department");
            Console.WriteLine("5. View Employees");
            Console.WriteLine("0. Exit");
            Console.Write("Choose an option: ");

            string choice = Console.ReadLine();
            Console.WriteLine();

            switch (choice)
            {
                case "1": AddEmployee(); break;
                case "2": EditEmployee(); break;
                case "3": DeleteEmployee(); break;
                case "4": AssignJobDept(); break;
                case "5": ViewEmployees(); break;
                case "0": return;
                default: Console.WriteLine("Invalid choice."); break;
            }
        }
    }

    static void AddEmployee()
    {
        Console.Write("Enter employee name: ");
        string name = Console.ReadLine();

        employees.Add(new Employee
        {
            Id = nextId++,
            Name = name,
        });

        Console.WriteLine("Employee added successfully.");
    }

    static void EditEmployee()
    {
        var emp = FindEmployeeById();
        if (emp == null) return;

        Console.Write("Enter new name (leave blank to keep current): ");
        string newName = Console.ReadLine();
        if (!string.IsNullOrWhiteSpace(newName))
        {
            emp.Name = newName;
        }
        Console.WriteLine("Employee updated successfully.");
    }

    static void DeleteEmployee()
    {
        var emp = FindEmployeeById();
        if (emp == null) return;

        employees.Remove(emp);
        Console.WriteLine("Employee deleted successfully.");
    }

    static void AssignJobDept()
    {
        var emp = FindEmployeeById();
        if (emp == null) return;

        Console.Write("Enter job title: ");
        emp.JobTitle = Console.ReadLine();
        Console.Write("Enter department: ");
        emp.Department = Console.ReadLine();

        Console.WriteLine("Job title and department assigned successfully.");
    }

    static void ViewEmployees()
    {
        if (employees.Count == 0)
        {
            Console.WriteLine("No employees found.");
            return;
        }

        Console.WriteLine("Employees:");
        foreach (var emp in employees)
        {
            Console.WriteLine($"ID: {emp.Id}, Name: {emp.Name}, Job Title: {emp.JobTitle}, Department: {emp.Department}");
        }
    }

    static Employee FindEmployeeById()
    {
        Console.Write("Enter employee ID: ");
        if (!int.TryParse(Console.ReadLine(), out int id))
        {
            Console.WriteLine("Invalid ID.");
            return null;
        }

        var emp = employees.FirstOrDefault(e => e.Id == id);
        if (emp == null)
        {
            Console.WriteLine("Employee not found.");
            return null;
        }

        return emp;
    }
}
