﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Payroll_System
{
    public partial class Form1 : Form
    {
        private PaySlipList paySlipList = new PaySlipList();

        public Form1()
        {
            InitializeComponent();
            StyleForm();
        }

        private void StyleForm()
        {
            // Form Styling
            this.BackColor = Color.WhiteSmoke;
            this.Text = "Payroll System";
            this.Font = new Font("Segoe UI", 10);

            // Header Label
            label7.Text = "Payroll System";
            label7.Font = new Font("Segoe UI", 18, FontStyle.Bold);
            label7.ForeColor = Color.White;
            label7.BackColor = Color.SteelBlue;
            label7.TextAlign = ContentAlignment.MiddleCenter;
            label7.Dock = DockStyle.Top;
            label7.Height = 60;

            // Label Styling
            Label[] labels = { label1, label2, label3, label4, label5, label6 };
            foreach (Label lbl in labels)
            {
                lbl.ForeColor = Color.DarkSlateGray;
                lbl.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            }

            label1.Text = "Name";
            label2.Text = "Position";
            label3.Text = "Basic Salary";
            label4.Text = "Bonus";
            label5.Text = "Deductions";
            label6.Text = "Pay Slip Output";

            // Button Styling
            button1.Text = "Generate Pay Slip";
            button1.BackColor = Color.MediumSeaGreen;
            button1.ForeColor = Color.White;
            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderSize = 0;
            button1.Font = new Font("Segoe UI", 10, FontStyle.Bold);

            // TextBox Styling
            TextBox[] inputs = { txtName, txtPosition, txtBasicSalary, txtBonus, txtDeductions };
            foreach (TextBox txt in inputs)
            {
                txt.BackColor = Color.White;
                txt.ForeColor = Color.Black;
                txt.Font = new Font("Segoe UI", 10);
            }

            // Output Box Styling
            txtOutput.BackColor = Color.White;
            txtOutput.ForeColor = Color.DarkGreen;
            txtOutput.Font = new Font("Consolas", 10);
            txtOutput.ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                PaySlip slip = new PaySlip()
                {
                    Name = txtName.Text,
                    Position = txtPosition.Text,
                    BasicSalary = decimal.Parse(txtBasicSalary.Text),
                    Bonus = decimal.Parse(txtBonus.Text),
                    Deductions = decimal.Parse(txtDeductions.Text)
                };

                paySlipList.Add(slip);
                txtOutput.Text = slip.ToString();
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid numbers for salary, bonus, and deductions.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
